import 'ol/ol.css';
import Map from 'ol/Map';
import View from 'ol/View';
import {WFS, GeoJSON} from 'ol/format';
import {Tile as TileLayer, Vector as VectorLayer} from 'ol/layer';
import {bbox as bboxStrategy} from 'ol/loadingstrategy';
import XYZ from 'ol/source/XYZ';
import VectorSource from 'ol/source/Vector';
import {Stroke, Style,Fill} from 'ol/style';
import OSM from 'ol/source/OSM';

var vectorSource = new VectorSource({
  format: new GeoJSON(),
  strategy: bboxStrategy
});

var vector = new VectorLayer({
  source: vectorSource,
});


var xyz = new TileLayer({
  projection: 'EPSG:2193',
  source: new XYZ({
    attributions: 'Tiles © <a href="https://services.arcgisonline.com/ArcGIS/' +
        'rest/services/World_Topo_Map/MapServer">ArcGIS</a>',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/' +
        'World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
  }),
})

var map = new Map({
  layers: [xyz,vector],
  target: document.getElementById('map'),
  view: new View({
    center: [1755099.9259,5917537.75],
    zoom: 18,
    minZoom: 1,
    maxZoom: 21
  })
});

const WATERPIPE = 0 ;
const WASTEWATERPIPE = 1;
var layer = WATERPIPE; 

function updateUrl(index) {
  console.log(index)
  layer = index;
  var yearBefore = 2020 - parseInt(yearInput.value);
  var urls = [
   
    function(extent) {
      return 'http://localhost:8080/geoserver/geoinfo/ows?service=WFS' + 
      '&version=1.0.0&request=GetFeature&typeName=geoinfo%3Awaterpipe&outputFormat=application%2Fjson'
      +'&srsname=EPSG:2193&' + 'cql_filter=(bbox(geom,' + extent.join(',') + ',%27EPSG:2193%27)and(installed<%27' + yearBefore + '-1-1%27))';
  
    },
  
    function(extent) {
      return 'http://localhost:8080/geoserver/geoinfo/ows?service=WFS' + 
      '&version=1.0.0&request=GetFeature&typeName=geoinfo%3Awastewater_pipe&outputFormat=application%2Fjson'
      +'&srsname=EPSG:2193&' + 'cql_filter=(bbox(geom,' + extent.join(',') + ',%27EPSG:2193%27)and(installed<%27' + yearBefore + '-1-1%27))';
 
  
    },
  
  ];

  if(index == WATERPIPE) vector.setStyle(new Style({stroke: new Stroke({color: 'rgba(0, 0, 255, 1.0)',width: 2})}))
  if(index == WASTEWATERPIPE) vector.setStyle(new Style({stroke: new Stroke({color: 'rgba(255, 0, 0, 1.0)',width: 2})}))
  vectorSource.setUrl(urls[index]);
  vectorSource.refresh();
}

//layer switch logic
var buttons = document.getElementsByClassName('switcher');
for (var i = 0, ii = buttons.length; i < ii; ++i) {
  var button = buttons[i];
  button.addEventListener('click', updateUrl.bind(null, Number(button.value)));
}

//item select logic
var selected = null;
var attr = document.getElementById('attr');
var highlightStyle = new Style({
  fill: new Fill({
    color: 'rgba(255,255,255,0.7)'
  }),
  stroke: new Stroke({
    color: '#3399CC',
    width: 5
  })
});

map.on('singleclick', function(e) {
  if (selected !== null) {
    selected.setStyle(undefined);
    selected = null;
  }

  map.forEachFeatureAtPixel(e.pixel, function(f) {
    selected = f;
    f.setStyle(highlightStyle);
    return true;
  });

  if (selected) {
    attr.innerHTML = '&nbsp;Attribute: gis_id : ' + selected.get('gis_id') + ' Installed Date : ' + selected.get('installed');
  } else {
    attr.innerHTML = '&nbsp;Attribute: ';
  }
});

//year scoll bar logic
var yearInput = document.getElementById('year-before');
function updateYear() {
  var yearBefore = 2020 - parseInt(yearInput.value);
  var div = document.getElementById('status');
  div.querySelector('span.year-before').textContent = yearInput.value;
  console.log(yearBefore);
  updateUrl(layer);
}

//search text input logic
function logSearch(event) {
  
  let item = document.getElementById('item').value;

  let search_layer = '';

  if(layer == WATERPIPE) {
    search_layer = 'waterpipe';
  }
  else if(layer == WASTEWATERPIPE) {
    search_layer = 'wastewater_pipe';
  }
  
  let search_url = 'http://localhost:8080/geoserver/geoinfo/ows?service=WFS' + 
  '&version=1.0.0&request=GetFeature&typeName=geoinfo%3A' + search_layer + '&outputFormat=application%2Fjson'
  +'&cql_filter=(gis_id =%27' + item + '%27)';

  console.log('layer'+layer);
  console.log('url'+search_url)

  // search layer and zoom to requested item
  
  fetch(search_url).then(function(response) {
      return response.json();
    }).then(function(json) {
      var feature = new GeoJSON().readFeatures(json);
      var polygon = feature[0].values_.geometry;
      map.getView().fit(polygon, {padding: [170, 50, 30, 150]});
      log.textContent = `Item Found and Zoomed`;
      //myFeature = vector.getFeaturesByAttribute('gis_id',item);
      
    }).catch(error => {
      log.textContent = `Item Not Found`;
    });
    
  event.preventDefault();
}

var search = document.getElementById('search');
var log = document.getElementById('log');

search.addEventListener('submit', logSearch);
yearInput.addEventListener('input', updateYear);
yearInput.addEventListener('change', updateYear);

updateUrl(0);
updateYear();

